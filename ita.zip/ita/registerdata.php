<?php
session_start();

$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$city=$_POST['city'];
$location=$_POST['location'];
$flatno=$_POST['flatno'];
$mobileno=$_POST['mobileno'];

$_SESSION["email"]=$email;


if($firstname && $lastname && $password && $email && $city && $location && $flatno && $mobileno){
	$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");
//	mysqli_select_db("lib") or die("Coldn't Connect!");
	
	
	$query=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		echo '<script language="javascript">';
		echo 'alert("User already exist!!")';
		echo '</script>';
		header("Location:register.php");	
		}
		
	else{
		
		$query1=mysqli_query($connect,"INSERT INTO customer(firstname,lastname,password,email,city,location,flatno,mobileno) VALUES('$firstname','$lastname','$password','$email','$city','$location','$flatno','$mobileno')");
				
			
			if(!$query1){
					die('error inserting new record') ;
	  
			}	
			else
			{
					header("Location:account.php");
					echo "done";
			}
		}
			
	}
	else
		die("That user doesn't exist!");
	
$queryy=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
$row = mysqli_fetch_assoc($queryy);
$cid=$row['srno'];
$_SESSION["cid"]=$cid;						

?>