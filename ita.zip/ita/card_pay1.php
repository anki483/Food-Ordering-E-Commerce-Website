<?php
session_start();
$password=$_POST['password'];
echo$password;
$email=$_POST['email'];
echo $email;
//$cid=$_SESSION['cid'];
$total=$_POST['total'];
echo$total;
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM card_payment WHERE username='$email'");
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
      $card_type=$row['card_type'];
	  $card_password=$row['card_password'];
	  $card_no=$row['card_no'];
	$amount1=$row['amount'];
}
}
$query1=mysqli_query($connect,"SELECT * FROM card_payment WHERE username='admin'");
if (mysqli_num_rows($query1) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query1)) {
      
	$amount2=$row['amount'];
	echo$amount2;
}
}
if($card_password==$password){
	$query2=mysqli_query($connect,"UPDATE card_payment SET amount=$amount1-$total WHERE username='$email'");
	if($query2){
			$query3=mysqli_query($connect,"UPDATE card_payment SET amount=$amount2+$total WHERE username='admin'");
	}
	
}

header('location:last.php');
?>