<?php
session_start();
$cid=$_SESSION['cid'];
$total=$_POST['total'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$location=$_POST['location'];
$flatno=$_POST['flatno'];
$mobileno=$_POST['mobileno'];
$email=$_POST['email'];
$city=$_POST['city'];
time();
	date_default_timezone_set("Asia/Calcutta");
	$timer = date( 'H:i:s', time());
	
$time =$_POST['time'];

if($time < $timer){
		$message = "Time should be greater than current time.";
		echo "<script type='text/javascript'>alert('$message');</script>";
		die("<a href='bill.php'>Back to bill</a>");
	}
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM card_payment WHERE username='$email'");
$query2=mysqli_query($connect,"INSERT INTO delivery_info(lastname,flatno,location,city,mobileno,delivery_time,firstname,cid,total) VALUES('$lastname','$flatno','$location','$city','$mobileno','$time','$firstname','$cid','$total')");
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
      $card_type=$row['card_type'];
	  $card_password=$row['card_password'];
	  $card_no=$row['card_no'];
	
}
}
$query3=mysqli_query($connect,"SELECT oid FROM delivery_info order by oid desc");
if (mysqli_num_rows($query3) > 0) {
    // output data of each row
    $row1 = mysqli_fetch_assoc($query3);
     $oid=$row1['oid'];
	$_SESSION['oid']=$oid;
	

}
$email=$_SESSION['email'];
?>	

<html>
<head>
	<title>foodie</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body background="admin1.jpg">
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			
		</div>
		<div>
			<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>">logout</a></li>
			</ul>
		</div>
	
</nav>


  <div class="modal-dialog">
  
     <br/><br/>
          <h1 class="text-center">Card Details</h1><br/><br/><br/>
          <form class="form col-md-12 center-block" method="post" action="card_pay1.php">
		 
            <div class="form-group"><table><tr><td style="width:110px;"><h4><b>First name :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="firstname" value="<?php echo$firstname;?>" readonly>
            </td></tr></table></div>
			
			<div class="form-group"><table><tr><td style="width:110px;"><h4><b>Last name :</b></h4></td><td>
              <input type="text" class="form-control input-lg" name="lastname" value="<?php echo$lastname;?>" readonly></td></tr></table>
            </div>
           
			
			<div class="form-group"><table><tr ><td style="width:110px;"><h4><b>Email</b></td><td>
				<input type="email" class="form-control input-lg" name="email" value="<?php echo$email;?>" readonly></td></tr></table>
			</div>
		

  
<br><div class="form-group"><table><tr><td style="width:110px;"><h4><b>Location :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="location" value="<?php echo$location;?>"readonly></td></tr></table>
            </div>
			
			<div class="form-group"><table><tr><td style="width:110px;"><h4><b>City :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="city" value="<?php echo$city;?>"readonly></td></tr></table>
            </div>
			
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Flat no :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="flatno" value="<?php echo$flatno;?>"readonly></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Mobileno :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="mobileno" value="<?php echo$mobileno;?>"readonly></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Total :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="total" value="<?php echo$total;?>" readonly></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Card no :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="card_no" value="<?php echo$card_no;?>"></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Card type :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="card_type" value="<?php echo$card_type;?>"></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Card password :  </h4></td><td>
              <input type="password" class="form-control input-lg" name="password" required></td></tr></table>
            </div>
            <div class="form-group"><table><tr><td style="width:365px;">
				<input id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="PAY">
              <input type="hidden" name="cid" value="<?php echo $row["cid"]; ?>"<?php echo $row["cid"]; ?>" />
              
			 <!---<span><?php echo $error; ?></span>-->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>



</body>
</html>
