<?php
	session_start();


$name=$_POST['name'];
$content= $_POST['content'];
$price=$_POST['price'];
$quantity=$_POST['quantity'];



if(isset($_POST['add_to_cart']))
{
			$connect= mysqli_connect("localhost","root","","food ordering") or die("Couldn't find...");
		$query=mysqli_query($connect,"SELECT id,name,content,price FROM tbl_product WHERE  id='$_GET["id"]'");

		
		while($row = mysqli_fetch_assoc($query))
		 {
			$name=$row["name"];
			$id=$row["id"];
			$price=$row["price"];
			
		}
			
		    $_SESSION["id"]=$id;
             $bid=$_SESSION["id"];
			 $total=0;
					
					$query1=mysqli_query($connect,"INSERT INTO order(id,name,quantity,price,total) VALUES('$id','$name','$quantity','$price','$total') where id=$bid and
					$total = $total + ($price * $quantity);  ");

					
					
					
					
					
					
			
					 
					
						if ($query1)
						{
					header("location: menu3.php");
							
						}
						
			
					
}


?>
