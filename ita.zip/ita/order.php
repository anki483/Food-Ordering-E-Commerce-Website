
<?php
//include('config.php');
if(isset($_SESSION['login_user'])){
header("location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>foodie || Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="index.php">foodie</a>
		</div>
		
	<div>
		<ul class="nav navbar-nav navbar-right">
			<!---<li><a href="admin.php"><span class="glyphicon glyphicon-wrench"></span> Admin</a></li>-->
			<li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
			<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		</ul>
	</div>
</nav>

  

 <div class="modal-dialog">
  
       
          <h2 class="text-center">Order now</h2>
   <form class="form col-md-12 center-block" method="post" action="menu.php">
			<div class="form-group">

  <select name="city" class="form-control input-lg" placeholder="city" >
  <option value="comedy">Ahmedabad</option>
  <option value="travel">Surat</option>
  <option value="personal">Vadodara</option>
  
</select><br></div>
			<div class="form-group">
              <input type="text" class="form-control input-lg" name="location" placeholder="location">
            </div>
			
			
            <div class="form-group">
				<input id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="order">
              
        
			 <!---<span><?php echo $error; ?></span>-->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>




</body>
</html>