<?php
session_start();
//$cid=$_SESSION['cid'];
$oid=$_SESSION['oid'];
$order_id=$_SESSION['order_id'];
?>

<?php
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM delivery_info WHERE oid='$oid'");
	$row = mysqli_fetch_assoc($query);
			//$oid=$row['oid'];
			//$cid=$row['cid'];
			$firstname=$row['firstname'];
			$lastname=$row['lastname'];
		$time=$row['delivery_time'];
			$city=$row['city'];
			$location=$row['location'];
			$mobileno=$row['mobileno'];
			$flatno=$row['flatno'];
	


$result1 = mysqli_query($connect,"SELECT total FROM tbl_order WHERE order_id = $order_id"); 
$row3 = mysqli_fetch_assoc($result1); 
$sum = $row3['total'];	
?>

<html>
<head>
	<title>foodie</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<style>
	
.ii {
    padding: 0px 0px 50px 580px;
}
	</style>
</head>
<body background="admin1.jpg">
<script> alert("Payment is SUCCESSFUL") </script>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
	<div class="navbar-header">
			<a class="navbar-brand" href="account.php">Continue Ordering</a>
		</div>
			<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>">logout</a></li>
			</ul>
		
	</div>
	
</nav>

 <div class="fo"><center><br><br><br><br>
								<h1><u>ORDER REVIEW</u></h1><br><br><br><br>
                     </center> 
						<div class="ii">
                     <table align="center" width="50%"><tr> <h4 class="text-info">Name : <?php echo $firstname.$lastname ?></h4></tr>
					  <tr><h4 class="text-info">City  : <?php echo $city ; ?></h4> </tr>
					<h4 class="text-info">Location : <?php echo $location ; ?></h4> 
					 <h4 class="text-info">Flat-No : <?php echo $flatno; ?></h4> 
					 <h4 class="text-info">Contact : <?php echo $mobileno; ?></h4>
					  <h4 class="text-info">Delivery Time: <?php echo $time; ?></h4>
					   <h4 class="text-info">Payment Status: Completed</h4>
					   </table>                                 
					</div>
                                </div><center><table border=2px width=25%>
					   <tr><th>Product Name</th><th>Quantity</th><th>Price</th></tr>
                          <?php
                        $result = mysqli_query($connect,"SELECT * FROM tbl_order_details WHERE order_id = $order_id "); 
							while($row2=mysqli_fetch_assoc($result)){ 
							$pname=$row2['name'];
							$quantity=$row2['quantity'];
							$price=$row2['price'];
						 $sql="UPDATE tbl_order SET order_status = 'Completed' WHERE order_id= '$order_id' ";
					  if(!mysqli_query($connect,$sql)){
					 die('error inserting new record'.mysqli_error($connect)) ;
					  }
	
					 ?> <tr>
					<td style="width:50%">	<?php echo $pname; 	?> </td>    
						<td style="width:10;">  <?php echo $quantity; ?></td>
                       <td style="width:20;"> <?php echo $price; ?>  </td>
						</tr>
						  <?php
}
?></table><center>
<table border=2px width=25%>
 <tr><td colspan=4 align=right><b>Total: &nbsp; <?php echo $sum; ?>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;</b></td></tr>
						</table>  
           	

</center>

</body>
</html>

