-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2017 at 05:03 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food`
--

-- --------------------------------------------------------

--
-- Table structure for table `1`
--

CREATE TABLE `1` (
  `cid` int(250) DEFAULT NULL,
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL,
  `subtotal` int(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `2`
--

CREATE TABLE `2` (
  `cid` int(250) DEFAULT NULL,
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL,
  `subtotal` int(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `5`
--

CREATE TABLE `5` (
  `cid` int(250) DEFAULT NULL,
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL,
  `subtotal` int(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `6`
--

CREATE TABLE `6` (
  `cid` int(250) DEFAULT NULL,
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL,
  `subtotal` int(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `11`
--

CREATE TABLE `11` (
  `cid` int(250) DEFAULT NULL,
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL,
  `subtotal` int(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `card_payment`
--

CREATE TABLE `card_payment` (
  `username` varchar(25) NOT NULL,
  `card_password` varchar(20) NOT NULL,
  `card_type` varchar(20) NOT NULL,
  `card_no` int(16) NOT NULL,
  `cvv_no` int(3) NOT NULL,
  `cbid` int(25) NOT NULL,
  `amount` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card_payment`
--

INSERT INTO `card_payment` (`username`, `card_password`, `card_type`, `card_no`, `cvv_no`, `cbid`, `amount`) VALUES
('admin', 'admin0000', 'visa', 123456789, 123, 0, 10370),
('john@gmail.com', 'meenu', 'visa', 234565768, 567, 2, 5540),
('pinkal@yahoo.com', 'pinks23', 'CitiBank', 234234567, 768, 0, 5000),
('tejal@gmail.com', 'tejal44', 'VISA', 123457891, 533, 0, 2000),
('tejas@gmail.com', 'tejas1', 'MasterCard', 1224453210, 626, 0, 19940);

-- --------------------------------------------------------

--
-- Table structure for table `cid`
--

CREATE TABLE `cid` (
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL,
  `subtotal` int(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `srno` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(10) NOT NULL,
  `city` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `flatno` varchar(50) NOT NULL,
  `mobileno` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`srno`, `firstname`, `lastname`, `email`, `password`, `city`, `location`, `flatno`, `mobileno`) VALUES
(1, 'tejal', 'malar', 'tejal@gmail.com', 'tejal', 'Surat', 'MTB,SVNIT', '599', 147483647),
(2, 'Tejaswita', 'Atal', 'tejas@gmail.com', 'tejas', 'Ahembdabad', 'MTB Svnit', '548', 851157378),
(3, 'John', 'Joseph', 'john@gmail.com', 'john', 'Vadodara', '25 Street south', 'B44', 88789456),
(4, 'aa', 'a', 'aa@gmail.com', 'a', 'Ahembdabad', 'aa', 'aa', 86),
(5, 'Admin', 'admin', 'admin@gmail.com', 'admin', 'city', 'location', 'flat', 12);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_info`
--

CREATE TABLE `delivery_info` (
  `lastname` varchar(20) NOT NULL,
  `flatno` varchar(10) NOT NULL,
  `location` varchar(25) NOT NULL,
  `city` varchar(10) NOT NULL,
  `mobileno` int(10) NOT NULL,
  `delivery_time` time NOT NULL,
  `oid` int(25) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `cid` int(25) NOT NULL,
  `total` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_info`
--

INSERT INTO `delivery_info` (`lastname`, `flatno`, `location`, `city`, `mobileno`, `delivery_time`, `oid`, `firstname`, `cid`, `total`) VALUES
('Atal', '548', 'svnit', 'Ahembdabad', 2147483647, '03:00:00', 12, 'Tejaswita', 2, 120),
('Atal', '548', 'svnit', 'Ahembdabad', 2147483647, '11:00:00', 15, 'Tejaswita', 2, 210),
('Atal', '548', 'svnit', 'Ahembdabad', 2147483647, '11:00:00', 16, 'Tejaswita', 2, 210),
('Atal', '548', 'svnit', 'Ahembdabad', 2147483647, '11:00:00', 17, 'Tejaswita', 2, 210),
('Atal', '548', 'svnit', 'Ahembdabad', 2147483647, '11:00:00', 18, 'Tejaswita', 2, 120),
('Atal', '548', 'svnit', 'Ahembdabad', 2147483647, '11:00:00', 19, 'Tejaswita', 2, 120),
('Atal', '548', 'MTB Svnit', 'Ahembdabad', 851157378, '11:00:00', 20, 'Tejaswita', 2, 250),
('Atal', '548', 'MTB Svnit', 'Ahembdabad', 851157378, '11:00:00', 22, 'Tejaswita', 4, 250),
('Joseph', 'B44', '25 Street south', 'Vadodara', 88789456, '12:00:00', 25, 'John', 2, 250),
('Atal', '548', 'MTB Svnit', 'Ahembdabad', 851157378, '15:00:00', 26, 'Tejaswita', 2, 250),
('Atal', '548', 'MTB Svnit', 'Ahembdabad', 851157378, '15:00:00', 27, 'Tejaswita', 2, 250),
('Atal', '548', 'MTB Svnit', 'Ahembdabad', 851157378, '15:00:00', 28, 'Tejaswita', 2, 250),
('Atal', '548', 'MTB Surat', 'Ahembdabad', 851157378, '15:00:00', 29, 'Tejaswita', 2, 110);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(10) NOT NULL,
  `cid` int(11) NOT NULL,
  `creation_date` date NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `total` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `cid`, `creation_date`, `order_status`, `total`) VALUES
(4, 1, '2017-04-15', 'pending', 120),
(5, 1, '2017-04-15', 'pending', 120),
(6, 1, '2017-04-15', 'pending', 120),
(7, 1, '2017-04-16', 'pending', 120),
(8, 1, '2017-04-16', 'pending', 120),
(9, 1, '2017-04-16', 'pending', 120),
(10, 1, '2017-04-16', 'pending', 120),
(11, 2, '2017-04-16', 'pending', 120),
(12, 2, '2017-04-17', 'pending', 210),
(13, 2, '2017-04-17', 'Completed', 120),
(14, 2, '2017-04-17', 'Completed', 250),
(16, 4, '2017-04-17', 'Completed', 220),
(17, 3, '2017-04-17', 'Completed', 250),
(18, 2, '2017-04-17', 'pending', 110),
(19, 2, '2017-04-17', 'pending', 110),
(20, 2, '2017-04-17', 'Completed', 250),
(21, 2, '2017-04-17', 'Completed', 110),
(22, 2, '2017-04-17', 'pending', 0),
(23, 2, '2017-04-17', 'pending', 110),
(24, 2, '2017-04-17', 'pending', 110),
(25, 2, '2017-04-17', 'pending', 110);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`id`, `order_id`, `name`, `price`, `quantity`) VALUES
(4, 4, 'Egg Paratha', 120, 4),
(5, 4, 'Frankie Lal Badshah', 130, 3),
(6, 4, 'Veg Prathas', 110, 1),
(7, 5, 'Cream Cheese Bagel', 120, 4),
(8, 5, 'Veg Prathas', 110, 3),
(9, 6, 'Veg Prathas', 110, 1),
(10, 7, 'Veg Prathas', 110, 2),
(11, 7, 'Paneer Pestoni', 200, 1),
(12, 8, 'Cream Cheese Bagel', 120, 1),
(13, 9, 'Frankie Lal Badshah', 130, 1),
(14, 10, 'Cream Cheese Bagel', 120, 1),
(15, 11, 'Egg Paratha', 120, 1),
(16, 12, 'Kadai Paneer', 210, 1),
(17, 13, 'Cream Cheese Bagel', 120, 1),
(18, 14, 'Belgian Choclate Brownie', 250, 1),
(20, 16, 'Veg Prathas', 110, 2),
(21, 17, 'Cream Cheese Bagel', 120, 1),
(22, 17, 'Frankie Lal Badshah', 130, 1),
(23, 18, 'Veg Prathas', 110, 1),
(24, 19, 'Veg Prathas', 110, 1),
(25, 20, 'Egg Paratha', 120, 1),
(26, 20, 'Frankie Lal Badshah', 130, 1),
(27, 21, 'Veg Prathas', 110, 1),
(28, 23, 'Veg Prathas', 110, 1),
(29, 24, 'Veg Prathas', 110, 1),
(30, 25, 'Veg Prathas', 110, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `price` int(10) NOT NULL,
  `product_type` varchar(20) NOT NULL,
  `recomnd` varchar(3) NOT NULL,
  `quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `image`, `name`, `content`, `price`, `product_type`, `recomnd`, `quantity`) VALUES
(1, '/food/parathas.jpg', 'Veg Prathas', 'Three 5" Parathas with curd, butter, pickle and fruit bowl', 110, 'Brunch', 'yes', 6),
(2, '/ita/cream.jpg', 'Cream Cheese Bagel', 'A freshly baked bagel, topped with crunchy sesame seeds, with a peppered cream cheese filling.', 120, 'Brunch', '', 5),
(3, '/food/paneer_pestoni.jpg', 'Paneer Pestoni', 'Smothered with Pesto, covered with lettuce and a hearty fill of Paneer ', 200, 'Brunch', '', 3),
(4, '/food/egg.jpg', 'Egg Paratha', 'Three 5" Parathas (2 egg, 1 aloo) with curd, butter, pickle and fruit bowl', 120, 'Brunch', 'yes', 10),
(5, '/food/lal_baadshah.jpg', 'Frankie Lal Badshah', 'French goat cheese salad with cottage cheese panini.', 130, 'Brunch', '', 7),
(7, '/food/athena_goddess_platter.jpg', 'Athena Goddess Platter', 'A delicious platter of Tabbouleh, 2 generous half pita pockets with falafel and paneer, hummus, pickled.', 250, 'Mains', 'yes', 4),
(8, '/food/deccan_delight.jpg', 'Deccan Delight', 'Upma, Idli, Vada with Sambhar Chutney', 150, 'Mains', '', 2),
(9, '/food/frittata.jpg', 'Frittata', 'Two egg thick omelette with onions & potatoes, served with foccacia, fruit bowl, ketchup & butter', 150, 'Mains', '', 2),
(10, '/food/kadhai_paneer.jpg', 'Kadai Paneer', 'Panner light brown gravy with tamarind and spices mix', 210, 'Mains', 'yes', 3),
(11, '/food/royal_nizam.jpg', 'Royal Nizam', 'Mix veggies, pulao served with spicy hyderbaadi gravy.', 250, 'Mains', '', 3),
(12, '/food/subz_dum_biryani.jpg', 'Subz Dum Biryani', 'Multicoloured rice mix veg biryani with spicy chutney.', 240, 'Mains', '', 12),
(13, '/food/broc-o-loco.jpg', 'Broc-o-Loco', 'Broccoli with peaches coated with Thousand Island Dressing', 250, 'Salads', 'yes', 11),
(14, '/food/cannes_de_herbs.jpg', 'Cannes De Herbs', 'Pasta Salad with Hearty Veggies', 240, 'Salads', '', 15),
(15, '/food/classic.jpg', 'Classic', 'Fresh Iceberg Lettuce Salad with Caesar Dressing.', 220, 'Salads', '', 7),
(16, '/food/cous_cous.jpg', 'Cous Cous', 'Pearl Couscous in Pesto Sauce and Exotic Veggies', 160, 'Salads', 'yes', 3),
(17, '/food/tabbouleh_salad.jpg', 'Tabbouleh Salad', 'Refreshing Tabbouleh salad with the goodness of bulgur, parsley and tomatoes, tossed in a light ', 190, 'Salads', 'yes', 4),
(18, '/food/veg_caesar.jpg', 'Veg Caesar', 'Fresh Iceberg Lettuce Salad with mix vegetable Dressing', 220, 'Salads', 'yes', 5),
(19, '/food/belgian_choclate_brownie.jpg', 'Belgian Choclate Brownie', 'You''ll find yourself getting nutty surprises, thanks to crunchy walnuts, hiding skillfully in the beautiful, dark, fugdy goodness.', 250, 'Cake', '', 10),
(20, '/food/blueberry_muffin.jpg', 'Blueberry Muffin', 'For those who like a bit of fruit in their dessert, this is a dream. Supremely moist muffins dotted generously with little blue fruity jewels that surprise you in every bite.', 160, 'Cake', '', 12),
(21, '/food/choco.jpg', 'Nuetella Choco Muffin', 'A delightful duo of rich, moist chocolate cupcakes studded with chocolate chunks.', 200, 'Cake', 'yes', 8),
(22, '/food/lemon_cake.jpg', 'Lemon Cake', 'A sinful combination of freshly baked golden shortcrust pastry, lemon zest, lemon juice cooked to perfection to form a tiny lemon curd', 175, 'Cake', '', 7),
(23, '/food/Muffin.jpg', 'Muffin Dark', 'Chocolate lovers rejoice because we have the perfect treat for you. A delightful duo of rich, moist chocolate cupcakes studded with chocolate chunks.', 160, 'Cake', 'yes', 6),
(24, '/food/nutellacake.jpg', 'Banana Nutella Cake', 'A sinful combination of freshly baked golden shortcrust pastry, lemon zest, lemon juice cooked to perfection to form a tiny lemon curd.', 250, 'Cake', '', 5),
(25, '/food/chocolate_tart.jpg', 'Chocolate Tart', 'Smooth and Sinful, this decadent Jar Cake combines rich dark Chocolate and buttery toffee alternated with layers of moist Chocolate cake.', 175, 'Desserts', '', 11),
(26, 'dark_chocolate_toffee_truffle.jpg', 'Dark Chocolate Toffee Truffle', 'Smooth and Sinful, this decadent Jar Cake combines rich dark Chocolate and buttery toffee alternated with layers of moist Chocolate cake.', 200, 'Desserts', 'yes', 50),
(27, '/food/kheer.jpg', 'Kheer', 'A delectable Indian rice pudding flavored and garnished with dry fruits, typically served as a dessert', 110, 'Desserts', '', 50),
(28, '/food/lemon_tat.jpg', 'Lemon Tart', 'A sinful combination of freshly baked golden shortcrust pastry, lemon zest, lemon juice cooked to perfection to form a tiny lemon curd', 150, 'Desserts', '', 50),
(29, '/food/phirni.jpg', 'Phirni', 'A Punjabi delicacy served cold in small earthen sakoras. Made from rice that is soaked overnight, ground then cooked in milk and flavored with saffron, cardamom & garnished with dry fruits', 120, 'Desserts', 'yes', 50),
(30, '/food/tiramisu.jpg', 'Tiramisu', 'Soft sponge cake soaked in espresso with alternating layers of mascapone cheese, chocolate shavings and whipped cream. No wonder this well-loved Italian dessert translates to ''Pick me up''!', 150, 'Desserts', '', 50),
(31, '/food/annasbuttermilk.jpg', 'Anna''s Buttermilk', 'The spicy coolant that makes summer feel like spring (300ml)', 100, 'Drinks', 'yes', 50),
(32, '/food/cubancoldcoffee.jpg', 'Cold Coffee', 'The superpower of the best coffee on earth contained in a bottle (300ml)', 120, 'Drinks', '', 50),
(33, '/food/himalayanicedtea.jpg', 'Himalayan Iced Tea', 'The chilled amber beauty that gets you high in all the right ways (300ml)', 60, 'Drinks', 'yes', 50),
(34, '/food/raisins_cardamom.jpg', 'Raisins Cardamom', 'The wonder juice that works its magic, head to toe. Oh, yeah! (300ml Cold Press juice)', 130, 'Drinks', '', 50),
(35, '/food/turbocharger.jpg', 'Turbo Charger', 'The fountain of youth that fills up your wrinkles with dewy freshness (300ml Cold Press juice)', 100, 'Drinks', '', 50),
(36, '/food/watermelon.jpg', 'Watermelon', 'The wonderful watermelon elixir that is just fruit in a bottle (300ml)', 80, 'Drinks', 'yes', 50);

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `cid` int(250) DEFAULT NULL,
  `pid` int(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `content` varchar(250) DEFAULT NULL,
  `price` int(250) DEFAULT NULL,
  `quantity` int(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `card_payment`
--
ALTER TABLE `card_payment`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`srno`);

--
-- Indexes for table `delivery_info`
--
ALTER TABLE `delivery_info`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `srno` (`cid`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `delivery_info`
--
ALTER TABLE `delivery_info`
  MODIFY `oid` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `customer` (`srno`);

--
-- Constraints for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD CONSTRAINT `tbl_order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`order_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
