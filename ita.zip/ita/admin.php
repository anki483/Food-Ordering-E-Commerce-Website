<?php
	session_start();
include_once('config.php');
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
	?>
<html>
<head>
<title>
Foodie
</title>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<style>
	body{	font-family:serif;
	
	font-size:25px;
	
	background-image:url("re.png");
	background-size:100%;
	text-align:center;
	
	}
	</style>

</head>
<script>
function find(){

var string=document.getElementById("search").value;
		if ( string== null || string == "") {
        		alert("enter keywords");
				myForm2.search.focus();

        		return ;
   			}
			        	
			
			 var xhttp=null;
			 xhttp = new XMLHttpRequest();
			 if(xhttp){      
				xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
				document.getElementById("docs").innerHTML =this.responseText;
				 $('.docs').append(this.responseText);
				
			}
		};
  xhttp.open("GET", "adminFind.php?q="+string, true);
  xhttp.send();   

			 }else {
				 alert("error");
			 }
}
</script>
<script>
angular.module('DataEntry', [
  'ngRoute'
]).config(function ( $routeProvider ) {
  $routeProvider
    .when('addproduct', {
      templateUrl: 'views/addproduct.php',
      controller: 'MainCtrl'
    });
});
angular.module('DataEntry')
  .controller('MainCtrl',
    function MainCtrl ( $scope, $location ) {
      'use strict';
      $scope.ChangeView = function(view) {
        alert(view);
        $location.url(view);
      }
    });
</script>
 <body>      
	   
<nav class="navbar navbar-inverse">
<div class="navbar-header">
			<a class="navbar-brand" href="admin.php">Admin</a>
		</div>
	<div class="container-fluid">
	
		<div>
			<ul class="nav navbar-nav">
		 
			<li><a href="addproduct.php"> Add Product </a></li>
			<li><a href="delete_product.php">Delete product</a></li>
			
			</ul>
		</div>
			<div>
			<ul class="nav navbar-nav navbar-right">
				
				<li><a href="logout.php">logout</a></li>
			
			</ul>
		</div>
	</div>
	
</nav>
<br><br><br><br>

	   <div id ="middle" align="center">
				<form  class="frm"  >
                           <h1 id="1"> SEARCH by Product Type</h1 >
                           <input type = 'text' maxlength='90' name = 'search' id='search'/ >
<button type = 'button' name = 'submit'class="submit"onclick="find()" >Search</button>
    </form >
					

				 <div id = "docs"><i>content will appear here</i> </div>

			 </div>
<br><br><br><br>
<h1><u> Customer Details</u></h1><br>
</body>
</html>


<?php


$sql = "SELECT * FROM customer ORDER by srno ASC";
$result = mysqli_query($connect, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
	?>
        <!-- Modify views here -->
        <div class="main" ng-controller="MainCtrl">
            <main role="main">
                <div ng-view> 
	
	<b><table align="center" style="width:76%; font-size:15px; font-weight:bold;"><th><td>Sr No.</td><td  width='12%'>First Name</td><td  width='12%'>Last Name</td><td width='25%'>Email</td>
	<td width='10%'>City</td><td width='10%'>Location</td><td width='5%'>Flat No</td><td width='20%'>Mobile No</td></th></table></b>
	<?php
	while($row = mysqli_fetch_assoc($result)) {
        echo "<table border=2px width='76%' align='center'>"."<tr>". 
		
		 "<tr><td width='5%'>".$row["srno"]. "</td>" .
		 "<td width='10%'>". $row["firstname"]."</td>".
		 "<td width='10%'>". $row["lastname"]."</td>".
		  "<td width='25%'>". $row["email"]."</td>".
		 "<td width='10%'>". $row["city"]."</td>".
		 "<td width='10%'>". $row["location"]."</td>".
		 "<td width='5%'>". $row["flatno"]."</td>".
		 "<td width='19%'>". $row["mobileno"]."</td>".
		 "</table>";
	} 
} 
else {
    echo "0 results";
}

echo"<br><br><br><br>";
echo"<h1><u> Product Details</u></h1><br>";
		$sql1 = "SELECT * FROM tbl_product ORDER by id ASC";
		$result1 = mysqli_query($connect, $sql1);
		if (mysqli_num_rows($result1) > 0) {
			// output data of each row	
			?>
			
	<b><table align="center" style="width:76%; font-size:15px; font-weight:bold;"><th><td>Id No.</td><td  width='20%'>Product Name</td><td  width='25%'>Content</td>
	<td width='12%'>Price</td><td width='20%'>Product Type</td><td width='20%'>Recommend</td><td width='20%'>Quantity</td></th></table></b>
	<?php
		while($row1 = mysqli_fetch_assoc($result1)) {
				echo "<table border=2px width='75%' align='center'>"."<tr>". 
				
				 "<tr><td width='5%'>".$row1["id"]. "</td>" .
				 "<td width='10%'>". $row1["name"]."</td>".
				 "<td width='10%'>". $row1["content"]."</td>".
				  "<td width='5%'>". $row1["price"]."</td>".
				 "<td width='10%'>". $row1["product_type"]."</td>".
				 "<td width='10%'>". $row1["recomnd"]."</td>".
				 "<td width='5%'>". $row1["quantity"]."</td>".
				"</table>";
				 
			}
		} else {
			echo "0 results";
		}	
	
mysqli_close($connect);

?> 

 </div>
            </main>
        </div>