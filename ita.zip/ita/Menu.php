<html>
<head>
<title>
BLog</title>

<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
	<div class="navbar-header">
			<a class="navbar-brand" href="index.php">Home</a>
		</div>
		<div>
			<ul class="nav navbar-nav">
			<li class=""dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Ready to eat<span class="caret"></span></a>
					<ul class="dropdown-menu">
						
					  <li><a href="#">	Breakfast</a></li>
			  <li> <a href="#">Salads</a></li>
				<li> <a href="#">Combos</a></li>
				<li> <a href="#">Snacks</a></li>
				<li> <a href="#">South Indian</a></li>
				<li> <a href="#">Ice Cream</a></li>
				<li> <a href="#">Drinks</a></li>
				<li> <a href="#">Desserts</a></li>
					</ul>
			<li><a href="about.asp">Specials</a></li>
		<li><a href="about.asp">Offers</a></li>
		<li><a href="contact.asp">Cart</a></li>
	  
			</ul>
		</div>
		<div>
			<ul class="nav navbar-nav navbar-right">
				
				<li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
				<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
			</ul>
		</div>
	</div>
	
</nav>

</body>
</html>

?>
<?php   
 session_start();  
 
 $connect = mysqli_connect("localhost", "root", "", "food");  
 if (!$connect) 
{
    die("Connection failed: " . mysqli_connect_error());
}



if(isset($_GET["add"]))  
 {  

	  
					 $_SESSION['cart_'. $_GET['add']] = $_SESSION['cart_'. $_GET['add']] + '1' ;
				 
					 
      
	  
	  
	  
	  
	  }
	  ?>
	   <div style="clear:both"></div>  
                <br />  
                  
            
						  
<?php
	  foreach($_SESSION as $name => $value){
		  if($value>0){
			  if(substr($name,0,5)=='cart_'){
				  $id = substr($name,5, (strlen($name)-5));
				  $get= mysqli_query($connect,"SELECT id,name,price FROm tbl_product WHERE id = '$id'");
				  while($get_row = mysqli_fetch_assoc($get))
				  {
					  $sub=$get_row['price']*$value;
					  //echo $get_row['name'].'x'.$value.'@'.$get_row['price'].'='.$sub.'</br>';
					  
					  ?>
					  
					
						  
<?php						  
				  }
			  }
		  }
		  
		  else{
			  echo "your cart is empty.";
		  }
	  }
	 

  ?>
 
 
 
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           
<link rel="stylesheet" type="text/css" href="productstyle.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<style>
.button {
    display: block;
    width: 15px;
    height: 15px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 0px;
    color: white;
    font-weight: bold;
}
</style>		   
      </head>  
      <body>  
           <br />  
           <div class="container" style="width:1080px;">  
                <h3 align="center">OUR RECOMMENDATION</h3><br />  
                <?php  
                $query = "SELECT * FROM tbl_product ORDER BY date ASC";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                <div class="col-md-4">  
                     <form method="post" action="menu3.php?add=<?php echo $row["id"];?>">  
                          <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:20px;height:500px;" align="center">  
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" style="width:1500px;height=1000px;" /><br />  
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>  
							   <div style="border:0px; background-color:white; padding:0px;height:80px;margin:2px;" align="center">  
							    <h5 class="text-info"><?php echo $row["content"]; ?></h5>  
								
                               <h4 class="text-danger">Rs <?php echo $row["price"]; ?></h4>  
							  
                      
							   <input type="submit" name="add" style="margin-top:5px;background-color:#ed2365;border:1px solid #ed2365;" class="btn btn-success" value="Add to Cart" style="float: right"/>  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" /><>
                               							   
                                
                          </div>  
                     </form>  
					 
                </div>  
				
				
				
                <?php  
                     }  
                }  
                ?>  
	</body>
	</html>
				