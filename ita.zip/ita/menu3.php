<?php



 session_start();
 

 
 $connect = mysqli_connect("localhost", "root", "", "food ordering");  
 if (!$connect) 
{
    die("Connection failed: " . mysqli_connect_error());
}



if(isset($_GET["add"]))  
 {  

	                
					 $_SESSION['cart_'. $_GET['add']] = $_SESSION['cart_'. $_GET['add']] + '1' ;
					 
					
					 header('Location:menu3.php');
      
	  
	
	  
	  
	  }
	 
	 

  ?>
 
 <html>
<head>
	<style>
	
		<!--ul {
			list-style-type: none;
			margin: 0;
			padding: 0;
			overflow: hidden;
			background-color: #333;
		}

		li {
			float: left;
		}

		li a {
			display: block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
		}

		/* Change the link color to #111 (black) on hover */
		li a:hover {
			background-color: #111;
		}--->
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: black;
	text-decoration:none;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	text-decoration:none;
}

.dropdown-content a {
    color: #333;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
	text-decoration:none;
}

.dropdown-content a:hover {background-color: gray;text-decoration:none;color:white;}

.show {display:block;text-decoration:none;}


		
		
	</style>
</head>
<body>
		
	  
	</ul>
	<ul>
		<li><a href="about.asp">SignUp/SignIn</a></li>
		<li><li class="ReadyToEat">
		<a href="javascript:void(0)" class="dropbtn" onclick="myFunction()">Ready to Eat</a>
		<div class="dropdown-content" id="myDropdown">
			   <a href="#">	Breakfast</a>
			   <a href="#">Salads</a>
				<a href="#">Combos</a>
				<a href="#">Snacks</a>
				<a href="#">South Indian</a>
				<a href="#">Ice Cream</a>
				<a href="#">Drinks</a>
				<a href="#">Desserts</a>
		</div>
	  </li>
		<li><a href="about.asp">Specials</a></li>
		<li><a href="about.asp">Offers</a></li>
		<li><a href="cart.php">Cart</a></li>
	</ul>
	<script>
		/* When the user clicks on the button,
		toggle between hiding and showing the dropdown content */
		function myFunction() {
			document.getElementById("myDropdown").classList.toggle("show");
		}

		// Close the dropdown if the user clicks outside of it
		window.onclick = function(e) {
		  if (!e.target.matches('.dropbtn')) {

			var dropdowns = document.getElementsByClassName("dropdown-content");
			for (var d = 0; d < dropdowns.length; d++) {
			  var openDropdown = dropdowns[d];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
			}
		  }
		}
		</script>
</body>
	</html>
 
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           
<link rel="stylesheet" type="text/css" href="productstyle.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<style>
.button {
    
	
    margin:15px;
    background: #4E9CAF;
    padding: 5px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
}
</style>		   
      </head>  
      <body>  
           <br />  
           <div class="container" style="width:1080px;">  
                <h3 align="center">OUR RECOMMENDATION</h3><br />  
                <?php  
                $query = "SELECT * FROM tbl_product where quantity>0 ORDER BY id desc";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                <div class="col-md-4">  
                     <form method="post" action="menu3.php?add=<?php echo $row["id"];?>">  
                          <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:20px;height:500px;" align="center">  
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" style="width:1500px;height=1000px;z-index:-1" /><br />  
							   
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>  
							   <div style="border:0px; background-color:white; padding:0px;height:80px;margin:2px;" align="center">  
							    <h5 class="text-info"><?php echo $row["content"]; ?></h5>  
								</div>
                               <h4 class="text-danger">Rs <?php echo $row["price"]; ?></h4>  
							  
                             <!-- <div style="overflow: hidden; padding-right: .5em;"> <input type="text" name="quantity" class="form-control" placeholder="Add Quantity" style="width:150px;" /> </div>-->
							   <input type="submit" name="add" onclick="myfunction2()" style="margin-top:5px;background-color:#5cb85c;border:1px solid #5cb85c;" class="btn btn-success" value="Add to Cart" style="float: right"/>  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" /> 
							   
                               							   
                                
                          </div>  
                     </form>  
					 
                </div>  
				
				
				
                <?php  
                     }  
                }  
                ?>  
				<script> 
				function myfunction2(){
					alert("item added successfully");
				  }
				</script>
				</body>
				</html>
				