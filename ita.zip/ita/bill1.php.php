<?php
session_start();
$cid=$_SESSION['cid'];
?>

<?php
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM customer WHERE srno='$cid'");
	$row = mysqli_fetch_assoc($query);
			$cid=$row['srno'];
			$firstname=$row['firstname'];
			$lastname=$row['lastname'];
			$email=$row['email'];
			$city=$row['city'];
			$location=$row['location'];
			$mobileno=$row['mobileno'];
			$flatno=$row['flatno'];
			
	
$result = mysqli_query($connect,"SELECT SUM(subtotal) AS value_sum FROM `".$cid."`"); 
$row = mysqli_fetch_assoc($result); 
$sum = $row['value_sum'];	
?>

<html>
<head>
	<title>foodie</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="index.php">Home</a>
		</div>
		<div>
			<ul class="nav navbar-nav">
				<li><a href="menu.php">Home</a></li>
				
			</ul>
		</div>
	
</nav>


  <div class="modal-dialog">
  
     
          <h1 class="text-center">billing</h1>
          <form class="form col-md-12 center-block" method="post" action="registerdata.php">
		 
            <div class="form-group"><table><tr><td style="width:110px;"><h4><b>First name :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="firstname" value="<?php echo$firstname;?>">
            </td></tr></table></div>
			
			<div class="form-group"><table><tr><td style="width:110px;"><h4><b>Last name :</b></h4></td><td>
              <input type="text" class="form-control input-lg" name="lastname" value="<?php echo$lastname;?>"></td></tr></table>
            </div>
           
			
			<div class="form-group"><table><tr ><td style="width:110px;"><h4><b>email</b></td><td>
				<input type="email" class="form-control input-lg" name="email" value="<?php echo$email;?>"></td></tr></table>
			</div>
			<div class="form-group">
<table><tr><td style="width:110px;"><h4><b>City :  </h4></td><td>
  <input type="text" name="city" class="form-control input-lg" value="<?php echo$city?>" ></td></tr></table>

  
<br><table><tr><td style="width:110px;"><h4><b>location :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="location" value="<?php echo$location;?>"></td></tr></table>
            </div>
			
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>flat no :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="flatno" value="<?php echo$flatno;?>"></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Mobileno :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="mobileno" value="<?php echo$mobileno;?>"></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Total :  </h4></td><td>
              <input type="text" class="form-control input-lg" name="total" value="<?php echo$sum;?>"></td></tr></table>
            </div>
            <div class="form-group"><table><tr><td style="width:365px;">
				<input id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="done">
              
              
			 <!---<span><?php echo $error; ?></span>-->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>



</body>
</html>

