<?php
session_start();
include_once('config.php');
session_unset();
session_destroy();
session_start();
?>
<html>
<head>
	<style>

		.container{
			background-color: black;
			margin:0px;
			margin-top:10%;
			padding:0px;
			border: 1px solid black;
			height: 60%;
			z-index:-500;
		}
		
		ul {
		list-style-type: none;
		margin: 0px;
		padding: 0px;
		overflow: hidden;
		background-color: #333;
		}

		li {
			float: left;
		}

		li a, .dropbtn {
			display: inline-block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size:18px;
		}

		li a:hover, .dropdown:hover .dropbtn {
			background-color: gray;
			text-decoration:none;
		}

		li.dropdown {
			display: inline-block;
		}

		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			text-decoration:none;
		}

		.dropdown-content a {
			color: #333;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
			text-decoration:none;
		}

		.dropdown-content a:hover {background-color: gray;text-decoration:none;color:white;}

		.show {display:block;text-decoration:none;}


			video#bigvid { 
			position: fixed;
			top: 87%;
			left: 100%;
			min-width: 100%;
			min-height: 50%;
			width: 100%;
			height: 50%;
			z-index: 0;
			 -ms-transform: translateX(-100%) translateY(-100%);
			-moz-transform: translateX(-100%) translateY(-100%);
			-webkit-transform: translateX(-100%) translateY(-100%);
			transform: translateX(-100%) translateY(-100%);
			background-fixed;
		}	
		
	</style>
</head>
<body background="best.jpg">
		
	  
	<div class="con">
	<ul>
		<li style="float:right"><a href="login.php">Log In</a></li>
	    <li style="float:right"><a href="register.php">Sign Up</a></li>
		<li><li class="ReadyToEat">
		<a href="javascript:void(0)" class="dropbtn" onclick="myFunction()">Ready to Eat</a>
		<div class="dropdown-content" id="myDropdown">
			   <a href="salads2.php">Salads</a>
			   <a href="brunch2.php">Brunch</a>
				<a href="Mains2.php">Mains</a>
				<a href="cake2.php">Cakes</a>
				<a href="desserts2.php">Desserts</a>
				<a href="drinks2.php">Drinks</a>
				
		</div>
	  </li>
		<li><a href="specials.php">Specials</a></li>
		<li><a href="about.php">About</a></li>
	</ul>
	</div>
	<script>
		/* When the user clicks on the button,
		toggle between hiding and showing the dropdown content */
		function myFunction() {
			document.getElementById("myDropdown").classList.toggle("show");
		}

		// Close the dropdown if the user clicks outside of it
		window.onclick = function(e) {
		  if (!e.target.matches('.dropbtn')) {

			var dropdowns = document.getElementsByClassName("dropdown-content");
			for (var d = 0; d < dropdowns.length; d++) {
			  var openDropdown = dropdowns[d];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
			}
		  }
		}
		</script>

<br>
<br>
	

	<div class="container" width="100%" >	
	<video width="3080px" height="30%"  autoplay loop id="bigvid">
  <source src="innerchef.mp4" type="video/mp4">
  
  Your browser does not support the video tag.
</video>
<img src="eat.jpg" style="z-index:20;margin-top:0px;margin-left:0px;width:23%;">
<a href="menu.php"> <img src="chef4.jpg" style="z-index:20;margin-top:30px;margin-right:0px;width:23%;margin-left:770px;"> </a>
</div>

	</body>
	</html>
	
	

	
	
	