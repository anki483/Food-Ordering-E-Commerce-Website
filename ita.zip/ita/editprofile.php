<?php
session_start();
$email=$_SESSION["email"];
?>

<?php
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
	$row = mysqli_fetch_assoc($query);
			$cid=$row['srno'];
			$firstname=$row['firstname'];
			$lastname=$row['lastname'];
			$email=$row['email'];
			$city=$row['city'];
			$location=$row['location'];
			$mobileno=$row['mobileno'];
			$flatno=$row['flatno'];
			
			
			
			
	if(isset($_POST['update']))
	{
		
		$firstname=$_POST['firstname'];
        $lastname=$_POST['lastname'];
        $email=$_POST['email'];
        $city=$_POST['city'];
        $location=$_POST['location'];
        $flatno=$_POST['flatno'];
        $mobileno=$_POST['mobileno'];
		$query1=mysqli_query($connect,"Update  customer set firstname='$firstname',lastname='$lastname',email='$email',city='$city',location='$location',flatno ='$flatno',mobileno='$mobileno' where srno='$cid'");
		header('location:profile.php');
	}
	

?>

<html>
<head>
	<title>Profile Edit</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
</head>
<body  background="admin.jpg">
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		
			<div>
			<ul class="nav navbar-nav">
			
			<li><a href="profile.php">Profile</a></li>
	
		<li><a href="cart.php">Cart</a></li>
	
		
			</ul>
		</div>
		<div>
			
			<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>"">Logout</a></li>
			</ul>
		</div>
	</div>
	
</nav>

<div ng-app="">
 
<table><tr><td>

	<div class="modal-dialog" style="margin-left:240px">
        <h1 class="text-center"style="margin-left:-200px;">User Profile</h1><br>                   
        <h4 class="text-info">Name : {{firstname}} {{lastname}} </h4>
		<h4 class="text-info"> Email : <?php echo$email;?></h4>  
		<h4 class="text-info">City  : {{city}}</h4> 
		<h4 class="text-info">Location : {{location}}</h4> 
		<h4 class="text-info">Flat-No : {{flat_no}}</h4> 
		<h4 class="text-info">Contact : {{contact}}</h4><br><br>
		</div>	
</td>
 <td> <div class="modal-dialog" style="margin-left:300px">
  
     
          <h1 class="text-center"style="margin-left:-200px;">Edit Profile</h1><br>
          <form class="form col-md-12 center-block" method="post" action="editprofile.php">
		 
            <div class="form-group"><table><tr><td style="width:110px;"><h4><b>First name :  </h4></td><td>
              <input type="text" class="form-control input-lg" ng-model="firstname" name="firstname" placeholder="<?php echo$firstname;?>" required= "required" >
            </td></tr></table></div>
			<div class="form-group"><table><tr><td style="width:110px;"><h4><b>Last name :</b></h4></td><td>
              <input type="text" class="form-control input-lg" ng-model="lastname" name="lastname" placeholder="<?php echo$lastname;?>" required= "required"></td></tr></table>
            </div>
           
			
			<div class="form-group"><table><tr ><td style="width:110px;"><h4><b>Email :</b></td><td>
				<input type="email" class="form-control input-lg" name="email" value="<?php echo$email;?>" required= "required" readonly /></td></tr></table>
			</div>
			
			<div class="form-group">
	<table><tr><td style="width:110px;"><h4><b>City :  </h4></td><td>
		<select name="city" class="form-control input-lg"  ng-model="city" value="<?php echo$city?>" required= "required">
			  <option value="Ahembdabad" selected >Ahmedabad</option>
			  <option value="Surat">Surat</option>
			  <option value="Vadodara">Vadodara</option> 
			</select><br></td></tr></table>

	<table><tr><td style="width:110px;"><h4><b>Location :  </h4></td><td>
              <input type="text" class="form-control input-lg" ng-model="location" name="location" placeholder="<?php echo$location;?>" required= "required"></td></tr></table>
            </div>
			
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Flat no :  </h4></td><td>
              <input type="text" class="form-control input-lg" ng-model="flat_no" name="flatno" placeholder="<?php echo$flatno;?>" required= "required"></td></tr></table>
            </div>
			<div class="form-group">
			<table><tr><td style="width:110px;"><h4><b>Contact :  </h4></td><td>
              <input type="text" class="form-control input-lg" ng-model="contact" name="mobileno" placeholder="<?php echo$mobileno;?>" required= "required"></td></tr></table>
            </div>
			
            <div class="form-group"><table><tr><td style="width:365px;">
				<input id="button" type="submit" name="update" class="btn btn-success btn-lg btn-block" value="Update">
              
              
			 <!---<span><?php echo $error; ?></span>-->
            </div>
          </form>
      </div></td></tr></table>
     </div> 
  </div>
  </div>
</div>



</body>
</html>

