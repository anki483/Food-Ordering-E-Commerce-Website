<?php

session_start();
include_once('config.php');
//session_unset();
//		session_destroy();
//		session_start();
header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
$outp = "";
$_POST = json_decode(file_get_contents('php://input'), true);
	if(isset($_POST['email'])){
		$email = $_POST['email'];
			$_SESSION['email']=$email;
	}
	else
		$email = "dhavan05031997@gmail.com";
	if(isset($_POST['password'])){
		$password = $_POST['password'];
	}
	else
		$password="okay";

	$conn = new mysqli("localhost", "root", "", "food");
	if ($conn->connect_error) {
    	die("Connection failed: " . $conn->connect_error);
	} 

	$sql = "SELECT * FROM customer WHERE email='$email' AND password='$password'";

	$result = $conn->query($sql);
	$valid = '{"status" : "';
	if ($result->num_rows  > 0) {
	$valid .= 'true"}';
	} else {
	$valid .= 'false"}';
	}
	echo ($valid);
$numrows=mysqli_num_rows($result);
	if($numrows!==0){
		while($row=mysqli_fetch_assoc($result)){
			$dbemail = $row['email'];
			//$dbName=$row['Name'];
			$dbpassword=$row['password'];
			$cid=$row['srno'];
		}
		$_SESSION['cid']=$cid;
		$_SESSION['email']=$email;
		if($email==$dbemail  && ($password==$dbpassword)){
	//@$_SESSION['email']=$email;
$query1=mysqli_query($conn,"CREATE TABLE `".$cid."`(
	cid int(250),
	pid int(250),
	name varchar(250),
	image varchar(250),
	price int(250),
	quantity int(250),
	subtotal int(250)
)");
		}
	}
	$conn->close();
?>