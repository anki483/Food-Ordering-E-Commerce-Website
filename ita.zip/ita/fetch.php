<?php
//fetch.php
 //<button id="mybtn">book now</button></td>
session_start();
error_reporting();
$connect = mysqli_connect("localhost", "root", "", "food");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "SELECT * FROM tbl_product where  name LIKE '%$search%' OR product_type LIKE '%$search%'  order by id DESC";
}
else
{
 $query = "
  SELECT * FROM hotes ORDER BY hid
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{

 while($row = mysqli_fetch_array($result))
 {
  $output .= '
  
       <div class="col-md-4" style="margin-top:12px;">  
                          <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:20px;max-height:500px;" align="center">  
                               <img src="'. $row["image"].'" class="img-responsive" style="width:1500px;height=1000px;" /><br />  
                               <h5 class="text-info">.'$row["name"]'.</h5>  
                 <div style="border:0px; background-color:white; padding:0px;height:55px;margin:2px;overflow: hidden;" align="center">  
                 <h5 class="text-info">'.$row["content"].'</h5>  
                  </div>
                               <h4 class="text-danger">Rs '. $row["price"].'</h4>  
               
                               <input type="text" name="quantity" id="quantity'.$row["id"].'" class="form-control" value="1" />  
                               <input type="hidden" name="hidden_name" id="name'. $row["id"].'" value="'. $row["name"].'" />  
                               <input type="hidden" name="hidden_price" id="price'.$row["id"].'" value="'.$row["price"].'" />  
                               <input type="button" name="add_to_cart" id="'. $row["id"].'" style="margin-top:5px;background-color:#66cc66;border:1px solid #66cc66" class="btn btn-warning form-control add_to_cart" value="Add to Cart" />  
                          
              </div>  
                     </div>  
  ';
      

 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>
</body>
</html>
