<?php

// Inialize session
session_start();
if(isset($_GET["logout"])) {
	$cid=$_SESSION['cid'];
$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");
$query1=mysqli_query($connect,"DROP TABLE `".$cid."`");
if ($query1) {
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $connect->error;
}
} session_unset();
 session_destroy();


// Jump to login page
header('Location:home.php');

?>