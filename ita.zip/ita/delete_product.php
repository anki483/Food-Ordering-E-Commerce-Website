<?php
session_start();

if(isset($_POST['submitt'])){
$name=$_POST['name'];

if($name ){
	$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");
		
		
	
		 $query1=mysqli_query($connect,"DELETE from tbl_product where name='$name'");
	if($query1){
				echo '<script language="javascript">';
				echo 'alert("Successfully Deleted!")';
				echo '</script>';
				header('Refresh: 1;URL=http://localhost/ita/admin.php');
				
			}
		
	
}
else
{
	echo '<script language="javascript">';
echo 'alert("FAILED!! Enter Product Name First")';
echo '</script>';
}
}
?>

<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<title>Delete Product</title>
</head>
<body background="admin1.jpg">
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
		<a class="navbar-brand" href="admin.php">Back</a>
		</div>
		

</nav>

<form action="delete_product.php" class="form col-md-12 center-block" enctype="multipart/form-data" method="post" ><center>
<h1>Product</h1>
<div class="form-group"><center>
<input type="text" name="name" class="form-control input-lg"  style="width:500px;" placeholder="Name" ><br></div>

<div class="form-group">

<center>
 <div class="form-group"><input type="submit" value="submit" name="submitt"  class="form-control input-lg" style="width:500px;" /></div>

</div>
</center>
</div>
</form>

</body>
</html>
