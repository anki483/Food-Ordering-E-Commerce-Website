<?php   
 session_start();  
 
 $connect = mysqli_connect("localhost", "root", "", "food ordering");  
 if (!$connect) 
{
    die("Connection failed: " . mysqli_connect_error());
}
?>

<html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
		   <style>
		   
		.container{
			background-color: black;
			margin:0px;
			margin-top:10%;
			padding:0px;
			border: 1px solid black;
			height: 60%;
			z-index:-500;
		}
		
		ul {
		list-style-type: none;
		margin: 0px;
		padding: 0px;
		overflow: hidden;
		background-color: black;
		}

		li {
			float: left;
			color:black;
		}

		li a, .dropbtn {
			display: inline-block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size:18px;
		}

		li a:hover, .dropdown:hover .dropbtn {
			background-color: gray;
			text-decoration:none;
		}

		li.dropdown {
			display: inline-block;
		}

		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			text-decoration:none;
		}

		.dropdown-content a {
			color: #333;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
			text-decoration:none;
		}

		.dropdown-content a:hover {background-color: gray;text-decoration:none;color:black;}

		.show {display:block;text-decoration:none;}
		h4{font-size:30px;}
		h5{font-size:20px;}
		}

		</style>
      </head>  
      <body background="pen.jpg">  
           <br />
				<ul>
					<li style="float:right"><a href="about.asp">Log Out</a></li>
					<li><a href="menu3.php">Menu</a></li>
				</ul>
	
				<div class="new" style="padding:60px;">
                <h1 align="center" style="color:white;"><u>Order Review</u></h1><br />  
                <?php  
                $query = "SELECT * FROM delivery_info where first_name='aa'";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>
						<h4 class="text-info">Name: <?php echo $row["first_name"];echo" ";  echo $row["last_name"]; ?></h4>
						<h5 class="text-info">Address: <?php echo $row["house_no"] ; echo" ";echo $row["address"] ; echo" ";echo $row["city"]; ?></h5>
						<h5 class="text-info">Pin & State:<?php echo $row["state"]; echo" ";echo $row["pincode"]; ?></h5>
						<h5 class="text-info">Contact No. :<?php echo $row["mobile"]; ?></h5>
						<h4 class="text-info">Delivery Time :<?php echo $row["delivery_time"]; ?></h4>
				 <?php  
                     }  
                }  
                ?> 
				</div>
	
	</body>
	</html>