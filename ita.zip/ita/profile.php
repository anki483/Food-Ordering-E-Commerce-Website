
<?php
session_start();
$email=$_SESSION["email"];

// Create connection
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM customer WHERE email='$email'";
$result = mysqli_query($connect, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        //echo "".$row["blogger_username"]."!"; 
	$_SESSION['email']=$email;
	$cid=$row["srno"];
	$_SESSION['cid']=$cid;
	

	}
} else {
    echo "0 results";
}

	mysqli_close($connect);
?> 

<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
	
	<style>
	
	.fo{
		width:30%;
		height:40%;
		
		padding:20px;
		font-size:50px;
	}
	</style>
</head>

	<body background="admin.jpg">

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		
			<div>
			
			<ul class="nav navbar-nav">
			
				<li class=""dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Ready to eat<span class="caret"></span></a>
		    <ul class="dropdown-menu">
            
        <li>

        <a href=salad.php> Salads</a></li>

            <li>   <a href=brunch.php> Brunch</a></li>   <li>  <a href=mains.php> Mains</a></li>
              <li>      <a href=cake.php> cake</a></li>
                        <li>  <a href=Dessert.php>dessert</a></li>
                       <li>         <a href=drinks.php> Drinks</a></li>
          </ul>
			
			<li><a href="account.php">Menu</a></li>
	
		
		
			</ul>
		</div>
		<div>
			
			<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>"">Logout</a></li>
			</ul>
		</div>
	</div>
	
</nav>



	<br><br><br><br>
				
	<div class="container" style="width:1080px;">  
                
                <?php  
					$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
                $query = "SELECT * FROM customer where email='$email'";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                 ?>
                               <div class="fo">
                               <form method="post" action="editprofile.php">
                               <h4 class="text-info">Name : <?php echo $row["firstname"].'&nbsp'.$row["lastname"]; ?></h4>  
							   
								
                               <h4 class="text-info"> Email : <?php echo $row["email"]; ?></h4>  
							    <h4 class="text-info">City  : <?php echo $row["city"]; ?></h4> 
								<h4 class="text-info">Location : <?php echo $row["location"]; ?></h4> 
					 <h4 class="text-info">Flat-No : <?php echo $row["flatno"]; ?></h4> 
					 <h4 class="text-info">Contact : <?php echo $row["mobileno"]; ?></h4>
                                							
							     
						 
                              <br><br>
                              <input type="submit" name="edit" class="btn btn-success btn-lg btn-block" value="Edit" >  
                         
				</form>	
                                </div>	
				
                <?php  
                     }  
                }  
                ?>  
				
		
</body>
	
</html>