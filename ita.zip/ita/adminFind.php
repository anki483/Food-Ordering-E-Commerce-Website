<?php // Include confi.php
session_start();
// Create connection
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
 
if($_SERVER['REQUEST_METHOD'] == "GET"){
	$keyword=$_GET["q"];
	$search_exploded = explode ( " ", $keyword ); 
	$x = 0; foreach( $search_exploded as $search_each ) 
	{ $x++; $construct = "";
	if( $x == 1 ) $construct .="'$search_each'"; 
	else $construct .="'$search_each'"; } 
	$query = " SELECT * FROM tbl_product WHERE product_type = $construct "; 
	echo $construct;
	 $result = mysqli_query($connect,$query);
   $num= mysqli_num_rows($result);
	if($num==0){
	$output= "<p>Sorry, there are no matching result for <b> $keyword </b>. </br> </br> 1. Try more general words. for example: If you want to search 'how to create a website' then use general keyword like 'create' 'website' </br> 2. Try different words with similar meaning </br> 3. Please check your spelling</p>"; }
else { $output= "<p>$num results found !</p>"; 
while( $runrows = mysqli_fetch_assoc( $result ) ) { 
$name = $runrows ['name'];
 $content = $runrows ['content'];
 $url = $runrows ['image'];
 $price = $runrows ['price'];
$product_type= $runrows ['product_type'];
$quantity = $runrows ['quantity'];?>

<html>
<head>
</head>
<body>
<table align="center" width="65%"> <?php
$output.= "<tr><td  rowspan=2>
<p><a href='$url'> <b> $name</b> </a><br><img src='".$url."' style='max-height:100px; width:auto'/></td> <td colspan=3> $content </td>
<tr><td>PRICE: $price </td><td>QUANTITY: $quantity </td><td>TYPE: $product_type </td></tr></p>";
 }

}echo $output;

}
 mysqli_close($connect);

 ?> 
 </table>
 </body></html>