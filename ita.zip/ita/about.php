<?php   
 session_start();

 
 $connect = mysqli_connect("localhost", "root", "", "food");  
 if (!$connect) 
{
    die("Connection failed: " . mysqli_connect_error());
}
?>
	  
						  
<!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           
			<link rel="stylesheet" type="text/css" href="productstyle.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

			<style>
			.button {
				
				
				margin:15px;
				background: #4E9CAF;
				padding: 5px;
				text-align: center;
				border-radius: 5px;
				color: white;
				font-weight: bold;
			}
			ul {
		list-style-type: none;
		margin: 0px;
		padding: 0px;
		overflow: hidden;
		background-color: #333;
		}
		.cont{
			
			background-color:gray;
		}
		li {
			float: left;
		}

		li a, .dropbtn {
			display: inline-block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size:18px;
		}

		li a:hover, .dropdown:hover .dropbtn {
			background-color: gray;
			text-decoration:none;
		}

		li.dropdown {
			display: inline-block;
		}

		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			text-decoration:none;
		}

		.dropdown-content a {
			color: #333;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
			text-decoration:none;
		}

		.dropdown-content a:hover {background-color: gray;text-decoration:none;color:white;}

		.show {display:block;text-decoration:none;}
			
			</style>		   
      </head> 
	  
      <body background="anout.png">  
	  
		<ul>
		<li style="float:right"><a href="login.php">Log In</a></li>
	    <li style="float:right"><a href="register.php">Sign Up</a></li>
		<li><li class="ReadyToEat">
		<a href="javascript:void(0)" class="dropbtn" onclick="myFunction()">Menu</a>
		<div class="dropdown-content" id="myDropdown">
			   <a href="salads.php">Salads</a>
			   <a href="brunch.php">Brunch</a>
				<a href="Mains.php">Mains</a>
				<a href="cake.php">Cakes</a>
				<a href="desserts.php">Desserts</a>
				<a href="drinks.php">Drinks</a>
				
		</div>
	  </li>
		<li><a href="specials.php">Specials</a></li>
		<li><a href="home.php">Home</a></li>
		<li><a href="about.php">About</a></li>
	</ul>
	
			<script>
		/* When the user clicks on the button,
		toggle between hiding and showing the dropdown content */
		function myFunction() {
			document.getElementById("myDropdown").classList.toggle("show");
		}

		// Close the dropdown if the user clicks outside of it
		window.onclick = function(e) {
		  if (!e.target.matches('.dropbtn')) {

			var dropdowns = document.getElementsByClassName("dropdown-content");
			for (var d = 0; d < dropdowns.length; d++) {
			  var openDropdown = dropdowns[d];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
			}
		  }
		}
		</script>
		 <br />  
           
                <h1 align="center" style="color:white;"><u>HISTORY</u></h1><br />  
				<div class="cont" style="width:60%;text-align:center; margin:20px; padding:30px; margin-left:300px; font-size:30px;">
				<p> Chef was a cooking supply store on the Downtown Bloomington Square. It was started in August, 2005 by David Wade and his partner Stephen Chambers, 
				following an attempt to purchase near by Goods for Cooks. The innovative art gallery/boutique format was created following a careful examination of
				existing cooking supply stores.Inner Chef was the subject of vandalism in late 2005. The owner, an openly gay man, flies a rainbow-colored gay 
				rights flag outside his storefront. On one evening, two teenagers tore the flag down and defiled it. The teenagers turned themselves 
				in and claimed they didn't know it was a gay rights flag, but were more concerned that it was a desecration of the American flag. 
				Regardless, the controversy was widely reported and Inner Chef saw a spike in sales as patrons flocked to the store as a show of 
				solidarity.At the end of 2010, the company had a sale and closed its business in the first week of 2011.</p>
         </div>       
		</body>
	</html>