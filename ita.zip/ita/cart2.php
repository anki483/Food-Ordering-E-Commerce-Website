
<?php

session_start();
$cid=$_SESSION['cid'];
if(isset($_GET["add"])) {
	
	$pid=$_POST['pid'];
	$name=$_POST['name'];
	$price=$_POST['price'];
	$image=$_POST['image'];
						$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM `".$cid."` WHERE pid='$pid'");
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        //echo "".$row["blogger_username"]."!"; 
	//@$_SESSION['email']=$email;
	//$cid=$row["srno"];
$quantity=$row["quantity"];
$quantity1=$quantity+1;
$price=$row["price"];
	}
} else {
    echo "0 results";
}	if($quantity>0){
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		$query2=mysqli_query($connect,"UPDATE `".$cid."` SET quantity=$quantity+1,subtotal=$quantity1*$price WHERE pid='$pid'");
		if ($query2) {
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
			
		}
	else{
	 $query1=mysqli_query($connect,"INSERT INTO `".$cid."`(pid,name,price,quantity,image,subtotal) VALUES('$pid','$name','$price',1,'$image','$price')");
	if($query1){
				echo"successfully added";
				//header('Refresh: 10;URL=http://localhost/blog/success.php');
				
			}
			else{
				echo"error";
			}
	}
}
else{
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		$query2=mysqli_query($connect,"DELETE FROM `".$cid."` WHERE pid='$pid'");
		if ($query2) {
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
			
		}
	else{
	 $query1=mysqli_query($connect,"INSERT INTO `".$cid."`(pid,name,price,quantity,image,subtotal) VALUES('$pid','$name','$price',1,'$image','$price')");
	if($query1){
				echo"successfully added";
				//header('Refresh: 10;URL=http://localhost/blog/success.php');
				
			}
			else{
				echo"error";
			}
	}
	
}
}	
?>
<?php



if(isset($_GET["sub"])) {
	
	$pid=$_POST['pid'];
	$name=$_POST['name'];
	$price=$_POST['price'];
	$image=$_POST['image'];
						$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM `".$cid."` WHERE pid='$pid'");
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        //echo "".$row["blogger_username"]."!"; 
	//@$_SESSION['email']=$email;
	//$cid=$row["srno"];
$quantity=$row["quantity"];
$quantity1=$quantity-1;
$price=$row["price"];
	}
} else {
    echo "0 results";
}
if($quantity>1){
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		$query2=mysqli_query($connect,"UPDATE `".$cid."` SET quantity=$quantity-1,subtotal=$quantity1*$price WHERE pid='$pid'");
		if ($query2) {
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
			
		}
	else{
	 $query1=mysqli_query($connect,"INSERT INTO `".$cid."`(pid,name,price,quantity,image,subtotal) VALUES('$pid','$name','$price',1,'$image','$price')");
	if($query1){
				echo"successfully added";
				//header('Refresh: 10;URL=http://localhost/blog/success.php');
				
			}
			else{
				echo"error";
			}
	}
}
	else{
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		$query2=mysqli_query($connect,"DELETE FROM `".$cid."` WHERE pid='$pid'");
		if ($query2) {
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
			
		}
	else{
	 $query1=mysqli_query($connect,"INSERT INTO `".$cid."`(pid,name,price,quantity,image,subtotal) VALUES('$pid','$name','$price',1,'$image','$price')");
	if($query1){
				echo"successfully added";
				//header('Refresh: 10;URL=http://localhost/blog/success.php');
				
			}
			else{
				echo"error";
			}
	}
	
}
}	

if(isset($_POST['shop']))
{
	header('location:account.php');
}
?>		
<html>
<head>
<title>
FOOD</title>

<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
	<div>	<ul class="nav navbar-nav navbar-left">
			<li><a href="account.php">Menu</a></li></ul>
			<ul class="nav navbar-nav navbar-right">
			
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>"">logout</a></li>
			</ul>
		</div>
</nav>

</body>
</html>	
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           
<link rel="stylesheet" type="text/css" href="productstyle.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<style>
.button {
    display: block;
    width: 15px;
    height: 15px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 0px;
    color: white;
    font-weight: bold;
}
</style>		   
      </head>  
      <body>  
           <br />  
           <div class="container" style="width:1080px;">  
                
                <?php  
				
				$cid=$_SESSION['cid'];
					$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
                $query = "SELECT * FROM`".$cid."`ORDER BY pid ASC";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
             <div class="col-md-4">  
                      <form class="form col-md-12 center-block" action="cart.php?add=<?php echo $row["pid"];?>" method="post">
                          <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:15px;height:400px;" align="center">  
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" style="width:1500px;height=1000px;" /><br />  
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>  
							   <div style="border:0px; background-color:white; padding:0px;height:70px;margin:2px;" align="center">  
							   
								
                               <h4 class="text-info">Rs <?php echo $row["subtotal"]; ?></h4>  
							     <div class="form-group"><table><tr> 
				<td><input id="button" type="submit" name="add" class="btn btn-success btn-lg btn-block" value="+" align="left"></td>
				 <td style="width:20px;padding:10px;"><h4 class="text-info"> <?php echo $row["quantity"]; ?></h4> </td>
				
				<input type="hidden" name="name" value="<?php echo $row["name"]; ?>" />  
				<input type="hidden" name="image" value="<?php echo $row["image"]; ?>" />  
                               <input type="hidden" name="price" value="<?php echo $row["price"]; ?>" /> 
   	    <input type="hidden" name="cid" value="<?php echo $row["cid"]; ?>" /> 
 <input type="hidden" name="pid" value="<?php echo $row["pid"]; ?>" /> 	</form>
  <form class="form col-md-12 center-block" action="cart.php?sub=<?php echo $row["pid"];?>" method="post">
 <td><input id="button" type="submit" name="sub" class="btn btn-success btn-lg btn-block" value="-" align="right"></td></tr></table></div>
 	<input type="hidden" name="name" value="<?php echo $row["name"]; ?>" />  
				<input type="hidden" name="image" value="<?php echo $row["image"]; ?>" />  
                               <input type="hidden" name="price" value="<?php echo $row["price"]; ?>" /> 
   	    <input type="hidden" name="cid" value="<?php echo $row["cid"]; ?>"<?php echo $row["cid"]; ?>" /> 
 <input type="hidden" name="pid" value="<?php echo $row["pid"]; ?>" /> 	
							 </div>
                    
						 
                              
                                
                          </div>  
                    
					 </form>
                </div> 
		
				
                <?php  
                     }  
                }  
                ?>  
              <?php  
				
				$cid=$_SESSION['cid'];

                ?>  
				<div class="container" style="width:1080px;"
             <div class="col-md-4">  
                      <form class="form col-md-12 center-block" action="bill.php?" method="post">
                         
 <tr><td><input id="button" type="submit" name="order" class="btn btn-success btn-lg btn-block" value="Order" align="center"style="width:30%; margin-left:300px;"></td></form>
 
 <form class="form col-md-12 center-block" action="account.php?" method="post">
                          
 <td><input id="button" type="submit" name="shop" class="btn btn-success btn-lg btn-block" value="Continue Shopping" align="center" style="width:30%;  margin-left:300px;></td></tr></table>
 	<input type="hidden" name="cid" value="<?php echo $row["cid"]; ?>" />  
				
                    
						 
                              
                                
                          </div>  
                    
					 </form>
                </div> 
		
				
                <?php  
                 
                ?>  