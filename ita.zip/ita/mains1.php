
<?php
session_start();
$email=$_SESSION["email"];
// Create connection
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM customer WHERE email='$email'";
$result = mysqli_query($connect, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        //echo "".$row["blogger_username"]."!"; 
	@$_SESSION['email']=$email;
	$cid=$row["srno"];
	$_SESSION['cid']=$cid;

	}
} else {
    echo "0 results";
}

	mysqli_close($connect);
?> 

<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

	<body>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
			<div>
			<ul class="nav navbar-nav">
			<li class=""dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Ready to eat<span class="caret"></span></a>
					<ul class="dropdown-menu">
						
					 <li><a href="salads1.php">Salads</a>
			   <a href="brunch1.php">Brunch</a>
				<a href="mains1.php">Mains</a>
				<a href="cakes1.php">Cakes</a>
				<a href="desserts1.php">Desserts</a>
				<a href="drinks1.php">Drinks</a></li>
					</ul>
			<li><a href="specials1.php">Specials</a></li>
	
		<li><a href="cart.php">Cart</a></li>
	  <li><a href="profile.php">Profile</a></li>
			</ul>
		</div>
		<div>
			
			<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>"">logout</a></li>
			</ul>
		</div>
	</div>
	
</nav>
<img src="2.jpg" style="z-index:20;margin-top:0px;margin-left:0px;width:100%;">
           <br />  
		   <h1 align="center">Mains</h1><br /> 
<?php
if(isset($_GET["add"])) {
	
	$pid=$_POST['pid'];
	$name=$_POST['name'];
	$price=$_POST['price'];
	$image=$_POST['image'];
						$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM `".$cid."` WHERE pid='$pid'");
if (mysqli_num_rows($query) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($query)) {
        //echo "".$row["blogger_username"]."!"; 
	//@$_SESSION['email']=$email;
	//$cid=$row["srno"];
$quantity=$row["quantity"];
$quantity1=$quantity+1;
$price=$row["price"];
	}
} else {
    //echo "0 results";
}
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		$query2=mysqli_query($connect,"UPDATE `".$cid."` SET quantity=$quantity+1,subtotal=$quantity1*$price WHERE pid='$pid'");
		if ($query2) {?><script> alert("successfully added")</script>
				<?php
   // echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
			
		}
	else{
	 $query1=mysqli_query($connect,"INSERT INTO `".$cid."`(pid,name,price,quantity,image,subtotal) VALUES('$pid','$name','$price',1,'$image','$price')");
	if($query1){
				?><script> alert("successfully added")</script>
				<?php
				//header('Refresh: 10;URL=http://localhost/blog/success.php');
				
			}
			else{
				echo"error";
			}
	}
}	
?>				
				
	<div class="container" style="width:1080px;">  
                
                <?php  
					$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
                $query = "SELECT * FROM tbl_product where product_type='Mains' ORDER BY id ASC";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                <div class="col-md-4">  
                      <form class="form col-md-12 center-block" action="mains1.php?add=<?php echo $row["id"];?>" method="post">
                          <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:15px;height:400px;" align="center">  
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" style="width:1500px;height=1000px;" /><br />  
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>  
							   <div style="border:0px; background-color:white; padding:0px;height:70px;margin:2px;" align="center">  
							    <h5 class="text-info"><?php echo $row["content"]; ?></h5>  
								
                               <h4 class="text-info">Rs <?php echo $row["price"]; ?></h4>  
							     <div class="form-group">
				<input id="button" type="submit" name="add" class="btn btn-success btn-lg btn-block" value="ADD"></div>
				<input type="hidden" name="name" value="<?php echo $row["name"]; ?>" />  
				<input type="hidden" name="image" value="<?php echo $row["image"]; ?>" />  
                               <input type="hidden" name="price" value="<?php echo $row["price"]; ?>" /> 
   	
 <input type="hidden" name="pid" value="<?php echo $row["id"]; ?>" /> 	
							 </div>
                    
						 
                              
                                
                          </div>  
                    
					 </form>
                </div>  
				
				
				
                <?php  
                     }  
                }  
                ?>  
				
		
</body>
	
</html>