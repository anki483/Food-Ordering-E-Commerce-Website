<?php $connect = mysqli_connect("localhost","root","","food");
if (!$connect)
  {
  die('Could not connect: ' . mysqli_connect_error());
  }
  
 

?>