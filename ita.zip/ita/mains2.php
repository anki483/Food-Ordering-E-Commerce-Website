<?php   
 session_start();

 
 $connect = mysqli_connect("localhost", "root", "", "food");  
 if (!$connect) 
{
    die("Connection failed: " . mysqli_connect_error());
}
?>
	  
						  
<!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           
			<link rel="stylesheet" type="text/css" href="productstyle.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

			<style>
			.button {
				
				
				margin:15px;
				background: #4E9CAF;
				padding: 5px;
				text-align: center;
				border-radius: 5px;
				color: white;
				font-weight: bold;
			}
			ul {
		list-style-type: none;
		margin: 0px;
		padding: 0px;
		overflow: hidden;
		background-color: #333;
		}

		li {
			float: left;
		}

		li a, .dropbtn {
			display: inline-block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size:18px;
		}

		li a:hover, .dropdown:hover .dropbtn {
			background-color: gray;
			text-decoration:none;
		}

		li.dropdown {
			display: inline-block;
		}

		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			text-decoration:none;
		}

		.dropdown-content a {
			color: #333;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
			text-decoration:none;
		}

		.dropdown-content a:hover {background-color: gray;text-decoration:none;color:white;}

		.show {display:block;text-decoration:none;}
			
			</style>		   
      </head> 
	  
      <body>  
	  
		<ul>
		<li style="float:right"><a href="login.php">Log In</a></li>
	    <li style="float:right"><a href="register.php">Sign Up</a></li>
		<li><li class="ReadyToEat">
		<a href="javascript:void(0)" class="dropbtn" onclick="myFunction()">Menu</a>
		<div class="dropdown-content" id="myDropdown">
			  <a href="salads2.php">Salads</a>
			   <a href="brunch2.php">Brunch</a>
				<a href="Mains2.php">Mains</a>
				<a href="cake2.php">Cakes</a>
				<a href="desserts2.php">Desserts</a>
				<a href="drinks2.php">Drinks</a>
		</div>
	  </li>
		<li><a href="specials.php">Specials</a></li>
		<li><a href="home.php">Home</a></li>
		<li><a href="about.php">About</a></li>
	</ul>
	
			<script>
		/* When the user clicks on the button,
		toggle between hiding and showing the dropdown content */
		function myFunction() {
			document.getElementById("myDropdown").classList.toggle("show");
		}

		// Close the dropdown if the user clicks outside of it
		window.onclick = function(e) {
		  if (!e.target.matches('.dropbtn')) {

			var dropdowns = document.getElementsByClassName("dropdown-content");
			for (var d = 0; d < dropdowns.length; d++) {
			  var openDropdown = dropdowns[d];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
			}
		  }
		}
		</script>
			 <img src="2.jpg" style="z-index:20;margin-top:0px;margin-left:0px;width:100%;">
           <br />  
           <div class="container" style="width:1080px;">  
                <h1 align="center">Mains</h1><br />  
                <?php  
                $query = "SELECT * FROM tbl_product where product_type='Mains' ORDER BY id desc";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                <div class="col-md-4">  
                     <form method="post" action="menu4.php?add=<?php echo $row["id"];?>">  
                          <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:20px;height:500px;" align="center">  
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" style="width:1500px;height=1000px;" /><br />  
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>  
							   <div style="border:0px; background-color:white; padding:0px;height:80px;margin:2px;" align="center">  
							    <h5 class="text-info"><?php echo $row["content"]; ?></h5>  
								</div>
                               <h4 class="text-danger">Rs <?php echo $row["price"]; ?></h4>
							   <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
                     </div></form>  
				</div>  
				 <?php  
                     }  
                }  
                ?> 
				</div>
		</body>
	</html>