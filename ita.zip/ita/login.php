
<?php
session_start();
include_once('config.php');
session_unset();
		session_destroy();
		session_start();
?>
<!DOCTYPE html>
<html ng-app="myapp">
<head>
	<title>foodie || Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
 <!--<script type = "text/javascript" src = "js/logger.js"></script>-->
</head>
<body ng-controller = "empcontroller">
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="home.php">Home</a>
		</div>		
	<div>
		<ul class="nav navbar-nav navbar-right">
			<!---<li><a href="admin.php"><span class="glyphicon glyphicon-wrench"></span> Admin</a></li>-->
			<li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
			<li class="active"><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		</ul>
	</div>
</nav>

  <div class="modal-dialog">
  
     
          <h1 class="text-center">Log In</h1>
          <form class="form col-md-12 center-block" ng-submit="insertdata()">
            <div class="form-group">
              <input type="text" class="form-control input-lg" name="email" placeholder="email" ng-model="email">
            </div>
            <div class="form-group">
              <input type="password" class="form-control input-lg" name="password" placeholder="Password" ng-model="password">
            </div>
            <div class="form-group">
				<input id="button" type="submit" value="login" name="submit" class="btn btn-success btn-lg btn-block"  >
              
              <span class="pull-right"><a href="register.php">Register Here!!</a></span>
			  <!----<span><?php echo $error; ?></span>-->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>


      
  </div>
  </div>
</div>

    <script>
    var app = angular.module('myapp', []);
        app.controller('empcontroller', function($scope, $http) {
          $scope.insertdata= function(){
            $http.post("connectivity.php",{'email': $scope.email , 'password': $scope.password})  

            .success(function(data, status, headers, config) {
				console.log(data);
				
            if(data.status=='true'){
				//alert(data);
                window.location.href = 'account.php';
			}
			else if(data.status=='truee'){
				alert(data);
				 window.location.href = 'admin.php';
			}
		
            else 
//alert(data);
                window.location.href = 'home.php';
            })
          }
        });
</script>


</body>
</html>