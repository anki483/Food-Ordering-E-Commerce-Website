<?php  
 //cart.php  
 session_start();  
 $connect = mysqli_connect("localhost", "root", "", "food");  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Shopping Cart </title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      </head>  
      <body background="admin1.jpg">  
          
		<nav class="navbar navbar-inverse">
		<div class="navbar-header">
					<a class="navbar-brand" href="account.php">Menu</a>
		</div>
		<div class="container-fluid">
	
		<div>
			<ul class="nav navbar-nav">
			
			</ul>
		</div>
			<div>
			<ul class="nav navbar-nav navbar-right">
				
				<li><a href="logout.php">logout</a></li>
					
					</ul>
				</div>
			</div>
			
		</nav>
		<br><br><br><br>
           <div class="container" style="width:800px;">  
                <?php  
				$email=$_SESSION['email'];
				$cid=$_SESSION['cid'];
                if(isset($_POST["place_order"]))  
                {  
				$query1 = ""; 
					   foreach($_SESSION["shopping_cart"] as $keys => $values)  
                     {  
					 
					 $query1="UPDATE tbl_product SET quantity=quantity - '".$values["product_quantity"]."' where name='".$values["product_name"]."'";
					 mysqli_query($connect, $query1);
					 $q= "select * from tbl_product where name='".$values["product_name"]."'";
					$r= mysqli_query($connect, $q);
					while($row = mysqli_fetch_array($r)) { 
					 if($row["quantity"]<0){
						
						 $query1="UPDATE tbl_product SET quantity=quantity + '".$values["product_quantity"]."' where name='".$values["product_name"]."'";
					 mysqli_query($connect, $query1);
					  echo '<script language="javascript">';
				echo 'alert("' .$values["product_name"] . ' exceeding STOCK LIMIT!")';
				echo '</script>';
					 //echo $values["product_name"] ."cannot be added";
					 unset($_SESSION['shopping_cart'][$keys]);

					
					 }
					}
					
					 }
                     $insert_order = "  
                     INSERT INTO tbl_order(cid, creation_date, order_status)  
                     VALUES('$cid', '".date('Y-m-d')."', 'pending')  
                     ";  
                     $order_id = "";  
                     if(mysqli_query($connect, $insert_order))  
                     {  
                          $order_id = mysqli_insert_id($connect);  
                     }  
                     $_SESSION["order_id"] = $order_id;  
                     $order_details = "";  
                     foreach($_SESSION["shopping_cart"] as $keys => $values)  
                     {  
                          $order_details .= "  
                          INSERT INTO tbl_order_details(order_id, name, price, quantity)  
                          VALUES('".$order_id."', '".$values["product_name"]."', '".$values["product_price"]."', '".$values["product_quantity"]."');  
                          ";  
                     }  
                     if(mysqli_multi_query($connect, $order_details))  
                     {  
                          unset($_SESSION["shopping_cart"]);  
                          echo '<script>alert("You have successfully place an order...Thank you")</script>';  
                          echo '<script>window.location.href="cart.php"</script>';  
                     }  
                }  
                if(isset($_SESSION["order_id"]))  
                {  
                     $customer_details = '';  
                     $order_details = '';  
                     $total = 0;  
                     $query = '  
                     SELECT * FROM tbl_order  
                     INNER JOIN tbl_order_details  
                     ON tbl_order_details.order_id = tbl_order.order_id  
                     INNER JOIN customer  
                     ON customer.srno = tbl_order.cid 
                     WHERE tbl_order.order_id = "'.$_SESSION["order_id"].'"  
                     ';  
                     $result = mysqli_query($connect, $query);  
                     while($row = mysqli_fetch_array($result))  
                     {  
                          $customer_details = '  
                          <label>'.$row["firstname"].' '.$row["lastname"].'</label>  
                          <p>'.$row["flatno"].'</p>  
                          <p>'.$row["location"].', </p>  
                          <p>'.$row["city"].'</p>  
                          ';  
                          $order_details .= "  
                               <tr>  
                                    <td>".$row["name"]."</td>  
                                    <td>".$row["quantity"]."</td>  
                                    <td>".$row["price"]."</td>  
                                    <td>".number_format($row["quantity"] * $row["price"], 2)."</td>  
                               </tr>  
                          ";  
                          $total = $total + ($row["quantity"] * $row["price"]);  
                     } 
					  $order_id = $_SESSION["order_id"];
					$sqlinsert="UPDATE tbl_order SET total ='$total' WHERE order_id = '$order_id' ";
					  if(!mysqli_query($connect,$sqlinsert)){
					 die('error inserting new record'.mysqli_error($connect)) ;
					  }
					  
					  $query=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
						$row = mysqli_fetch_assoc($query);
						$cid=$row['srno'];
						$oid= $order_id+6;
						
						$sqlinsertt="UPDATE delivery_info SET cid = '$cid' WHERE oid='$oid' ";
					  if(!mysqli_query($connect,$sqlinsertt)){
					 die('error inserting new record'.mysqli_error($connect)) ;
					  }
                  $sql="UPDATE tbl_order SET cid = '$cid' WHERE order_id= '$order_id' ";
					  if(!mysqli_query($connect,$sql)){
					 die('error inserting new record'.mysqli_error($connect)) ;
					  }
                     echo '  
                     <h3 align="center">Order Summary for Order No.'.$_SESSION["order_id"].'</h3>  
                     <div class="table-responsive">  
                          <table class="table">  
                               <tr>  
                                    <td><label>Customer Details</label></td>  
                               </tr>  
                               <tr>  
                                    <td>'.$customer_details.'</td>  
                               </tr>  
                               <tr>  
                                    <td><label>Order Details</label></td>  
                               </tr>  
                               <tr>  
                                    <td>  
                                         <table class="table table-bordered">  
                                              <tr>  
                                                   <th width="50%">Product Name</th>  
                                                   <th width="15%">Quantity</th>  
                                                   <th width="15%">Price</th>  
                                                   <th width="20%">Total</th>  
                                              </tr>  
                                              '.$order_details.'  
                                              <tr>  
                                                   <td colspan="3" align="right"><label>Total</label></td>  
                                                   <td>'.number_format($total, 2).'</td>  
                                              </tr>  
                                         </table>  
                                    </td>  
                               </tr>  
                          </table>  
                     </div>  
                     ';  
                }  
                ?>  
				<table align="center"><tr><td align="left"> <form method="post" action="bill.php">
				<input type="submit" name="edit" class="btn btn-success btn-lg btn-block" value="Payment" >  
                </form> </td> <td>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td>
					<!--<td width="50%" align="right"><form method="post" action="card_pay.php">
				<input type="submit" name="edit" class="btn btn-success btn-lg btn-block" value="Payment" >  
                </form> </td>--> </tr></table>  
           </div>  
      </body>  
 </html> 
